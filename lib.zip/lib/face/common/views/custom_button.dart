import 'package:classcare/face/common/utils/extensions/size_extension.dart';
import 'package:classcare/face/theme.dart';
import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  final IconData? icon;

  const CustomButton({
    super.key,
    required this.text,
    this.onTap,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 0.05.sw),
        decoration: BoxDecoration(
          color: onTap != null ? buttonColor : buttonColor.withOpacity(0.5),
          borderRadius: BorderRadius.circular(0.02.sh),
        ),
        child: Padding(
          padding: EdgeInsets.all(0.03.sw),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(left: 0.03.sw),
                  child: Row(
                    children: [
                      if (icon != null)
                        Padding(
                          padding: EdgeInsets.only(right: 0.02.sw),
                          child:
                              Icon(icon, color: primaryBlack, size: 0.025.sh),
                        ),
                      Text(
                        text,
                        style: TextStyle(
                          color: primaryBlack,
                          fontSize: 0.025.sh,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              CircleAvatar(
                radius: 0.03.sh,
                backgroundColor:
                    onTap != null ? accentColor : accentColor.withOpacity(0.5),
                child: const Icon(
                  Icons.arrow_circle_right,
                  color: buttonColor,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
