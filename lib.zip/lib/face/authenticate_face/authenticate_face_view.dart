import 'dart:convert';
import 'dart:developer';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:classcare/face/authenticate_face/user_details_view.dart';
import 'package:classcare/face/common/utils/custom_snackbar.dart';
import 'package:classcare/face/common/utils/extract_face_feature.dart';
import 'package:classcare/face/common/views/camera_view.dart';
import 'package:classcare/face/common/views/custom_button.dart';
import 'package:classcare/models/user_model.dart';
import 'package:classcare/screens/student/mark_att.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_face_api/face_api.dart' as regula;
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

class AuthenticateFaceView extends StatefulWidget {
  const AuthenticateFaceView({super.key});

  @override
  State<AuthenticateFaceView> createState() => _AuthenticateFaceViewState();
}

class _AuthenticateFaceViewState extends State<AuthenticateFaceView> {
  final FaceDetector _faceDetector = FaceDetector(
    options: FaceDetectorOptions(
      enableLandmarks: true,
      performanceMode: FaceDetectorMode.accurate,
    ),
  );
  FaceFeatures? _faceFeatures;
  var image1 = regula.MatchFacesImage();
  var image2 = regula.MatchFacesImage();
  final TextEditingController _codeController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  String _similarity = "";
  bool _canAuthenticate = false;
  List<dynamic> users = [];
  bool userExists = false;
  UserModel? loggingUser;
  bool isMatching = false;
  int trialNumber = 1;
  bool _attendanceAlreadyMarked = false;

  Future<void> checkCodeAndProceed() async {
    String inputCode = _codeController.text.trim();
    if (inputCode.isEmpty) {
      CustomSnackBar.errorSnackBar("Enter the code to proceed");
      return;
    }
    try {
      final int code = int.tryParse(inputCode) ?? -1;
      if (code == -1) {
        CustomSnackBar.errorSnackBar("Invalid code format.");
        return;
      }
      final snapshot = await FirebaseFirestore.instance
          .collection('oneTimeCode')
          .where('code', isEqualTo: code)
          .get();
      if (snapshot.docs.isNotEmpty) {
        final data = snapshot.docs.first.data();
        final Timestamp timestamp = data['timestamp'];
        final DateTime date = timestamp.toDate();
        final DateTime now = DateTime.now();
        if (now.year == date.year &&
            now.month == date.month &&
            now.day == date.day) {
          _fetchUsersAndMatchFace();
        } else {
          CustomSnackBar.errorSnackBar("Code is not valid for today.");
        }
      } else {
        CustomSnackBar.errorSnackBar("Invalid code.");
      }
    } catch (e) {
      CustomSnackBar.errorSnackBar("Failed to verify code. Please try again.");
      print(e);
    }
  }

  Future<bool> checkLocationAndMarkAttendance() async {
    const double targetLatitude = 12.843814496917556;
    const double targetLongitude = 80.1532693162898;
    const double threshold = 2000.0;
    try {
      final Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.medium);
      final double distance = Geolocator.distanceBetween(position.latitude,
          position.longitude, targetLatitude, targetLongitude);
      if (distance <= threshold) {
        final String userId = FirebaseAuth.instance.currentUser?.uid ?? "";
        final String email = FirebaseAuth.instance.currentUser?.email ?? "";
        if (userId.isNotEmpty) {
          final DateTime now = DateTime.now();
          final QuerySnapshot attendanceSnapshot = await FirebaseFirestore
              .instance
              .collection('attendance')
              .where('email', isEqualTo: email)
              .where('date', isEqualTo: _getFormattedDate(now))
              .get();
          if (attendanceSnapshot.docs.isNotEmpty) {
            setState(() {
              _attendanceAlreadyMarked = true;
              isMatching = false;
            });
            showDialog(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text("Attendance"),
                content: const Text("Attendance is already marked!"),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child:
                        const Text("OK", style: TextStyle(color: Colors.black)),
                  ),
                ],
              ),
            );
            return false;
          }
          await FirebaseFirestore.instance.collection('attendance').add({
            'email': email,
            'timestamp': DateTime.now(),
            'date': _getFormattedDate(DateTime.now()),
          });
          CustomSnackBar.successSnackBar("Attendance marked successfully!");
          return true;
        }
      } else {
        CustomSnackBar.errorSnackBar(
            "You are not within the attendance range.");
        setState(() => isMatching = false);
        return false;
      }
    } catch (e) {
      CustomSnackBar.errorSnackBar("Failed to get location. Please try again.");
      print(e);
      return false;
    }
    return false;
  }

  String _getFormattedDate(DateTime date) =>
      "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";

  @override
  void dispose() {
    _faceDetector.close();
    _codeController.dispose();
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: 'Authenticate Face'
            .gradientText([Colors.blueAccent, Colors.purpleAccent])
            .animate()
            .fadeIn(),
        iconTheme: const IconThemeData(color: Colors.white70),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF0F0F0F),
              Color(0xFF1A1A2E),
              Color(0xFF16213E),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              TextFormField(
                controller: _codeController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Enter Code',
                  labelStyle: const TextStyle(color: Colors.white70),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: const BorderSide(color: Colors.white54),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: const BorderSide(color: Colors.white54),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: const BorderSide(color: Colors.blueAccent),
                  ),
                ),
              ),
              const SizedBox(height: 25),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.2)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: 15,
                        spreadRadius: 5,
                      )
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Stack(
                      children: [
                        CameraView(
                          onImage: (image) => _setImage(image),
                          onInputImage: (inputImage) async {
                            setState(() => isMatching = true);
                            _faceFeatures = await extractFaceFeatures(
                                inputImage, _faceDetector);
                            setState(() => isMatching = false);
                          },
                        ),
                        if (isMatching)
                          Center(
                            child: Container(
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                color: Colors.black.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: const Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  CircularProgressIndicator(
                                      color: Colors.blueAccent),
                                  SizedBox(height: 15),
                                  Text('Authenticating...',
                                      style: TextStyle(
                                          color: Colors.white70, fontSize: 16)),
                                ],
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 25),
              Animate(
                effects: const [SlideEffect()],
                child: CustomButton(
                  text: "Authenticate",
                  icon: Icons.fingerprint,
                  onTap: () {
                    if (_codeController.text.trim().isEmpty) {
                      CustomSnackBar.errorSnackBar("Enter the code to proceed");
                    } else {
                      setState(() {
                        isMatching = true;
                        _attendanceAlreadyMarked = false;
                      });
                      checkCodeAndProceed();
                    }
                  },
                ),
              ),
              if (_attendanceAlreadyMarked)
                Container(
                  margin: const EdgeInsets.only(top: 20),
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.green),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.check_circle, color: Colors.green),
                      SizedBox(width: 12),
                      Text("Attendance already marked!",
                          style: TextStyle(color: Colors.green, fontSize: 14)),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future _setImage(Uint8List imageToAuthenticate) async {
    image2.bitmap = base64Encode(imageToAuthenticate);
    image2.imageType = regula.ImageType.PRINTED;
    setState(() => _canAuthenticate = true);
  }

  double compareFaces(FaceFeatures face1, FaceFeatures face2) {
    double distEar1 = euclideanDistance(face1.rightEar!, face1.leftEar!);
    double distEar2 = euclideanDistance(face2.rightEar!, face2.leftEar!);
    double ratioEar = distEar1 / distEar2;

    double distEye1 = euclideanDistance(face1.rightEye!, face1.leftEye!);
    double distEye2 = euclideanDistance(face2.rightEye!, face2.leftEye!);
    double ratioEye = distEye1 / distEye2;

    double distCheek1 = euclideanDistance(face1.rightCheek!, face1.leftCheek!);
    double distCheek2 = euclideanDistance(face2.rightCheek!, face2.leftCheek!);
    double ratioCheek = distCheek1 / distCheek2;

    double distMouth1 = euclideanDistance(face1.rightMouth!, face1.leftMouth!);
    double distMouth2 = euclideanDistance(face2.rightMouth!, face2.leftMouth!);
    double ratioMouth = distMouth1 / distMouth2;

    double distNoseToMouth1 =
        euclideanDistance(face1.noseBase!, face1.bottomMouth!);
    double distNoseToMouth2 =
        euclideanDistance(face2.noseBase!, face2.bottomMouth!);
    double ratioNoseToMouth = distNoseToMouth1 / distNoseToMouth2;

    return (ratioEye + ratioEar + ratioCheek + ratioMouth + ratioNoseToMouth) /
        5;
  }

  double euclideanDistance(Points p1, Points p2) =>
      math.sqrt(math.pow((p1.x! - p2.x!), 2) + math.pow((p1.y! - p2.y!), 2));

  _fetchUsersAndMatchFace() {
    FirebaseFirestore.instance.collection("face").get().catchError((e) {
      log("Error: $e");
      setState(() => isMatching = false);
      CustomSnackBar.errorSnackBar("Something went wrong. Please try again.");
    }).then((snap) {
      if (snap.docs.isNotEmpty) {
        users.clear();
        for (var doc in snap.docs) {
          UserModel user = UserModel.fromJson(doc.data());
          if (_faceFeatures != null && user.faceFeatures != null) {
            double similarity =
                compareFaces(_faceFeatures!, user.faceFeatures!);
            if (similarity >= 0.8 && similarity <= 1.5)
              users.add([user, similarity]);
          }
        }
        setState(() => users.sort((a, b) => (((a.last as double) - 1).abs())
            .compareTo(((b.last as double) - 1).abs())));
        _matchFaces();
      } else {
        _showFailureDialog(
          title: "No Users Registered",
          description: "Register users before authenticating.",
        );
      }
    });
  }

  _matchFaces() async {
    bool faceMatched = false;
    for (List user in users) {
      image1.bitmap = (user.first as UserModel).image;
      image1.imageType = regula.ImageType.PRINTED;

      var request = regula.MatchFacesRequest();
      request.images = [image1, image2];
      try {
        dynamic value = await regula.FaceSDK.matchFaces(jsonEncode(request));
        var response = regula.MatchFacesResponse.fromJson(json.decode(value));
        dynamic str = await regula.FaceSDK.matchFacesSimilarityThresholdSplit(
            jsonEncode(response!.results), 0.75);
        var split = regula.MatchFacesSimilarityThresholdSplit.fromJson(
            json.decode(str));

        setState(() {
          _similarity = split!.matchedFaces.isNotEmpty
              ? (split.matchedFaces[0]!.similarity! * 100).toStringAsFixed(2)
              : "error";
          if (_similarity != "error" && double.parse(_similarity) > 90.00) {
            faceMatched = true;
            loggingUser = user.first;
          }
        });

        if (faceMatched) {
          bool isInRange = await checkLocationAndMarkAttendance();
          if (isInRange && mounted) {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => UserDetailsView(user: loggingUser!)));
          }
          break;
        }
      } catch (e) {
        log("JSON Parsing Error: $e");
        CustomSnackBar.errorSnackBar(
            "Authentication failed. Please try again.");
        setState(() => isMatching = false);
        return;
      }
    }
    if (!faceMatched) _handleFailedAuthentication();
  }

  _handleFailedAuthentication() {
    if (trialNumber == 4) {
      setState(() => trialNumber = 1);
      _showFailureDialog(
        title: "Authentication Failed",
        description: "Face doesn't match. Please try again.",
      );
    } else if (trialNumber == 3) {
      setState(() {
        isMatching = false;
        trialNumber++;
      });
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text("Enter Name"),
          content: TextFormField(
            controller: _nameController,
            style: const TextStyle(color: Colors.black),
            decoration: InputDecoration(
              enabledBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: Colors.black),
                borderRadius: BorderRadius.circular(8),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: Colors.black),
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                if (_nameController.text.trim().isEmpty) {
                  CustomSnackBar.errorSnackBar("Enter a name to proceed");
                } else {
                  Navigator.pop(context);
                  setState(() => isMatching = true);
                  _fetchUserByName(_nameController.text.trim());
                }
              },
              child: const Text("Done", style: TextStyle(color: Colors.black)),
            )
          ],
        ),
      );
    } else {
      setState(() => trialNumber++);
      _showFailureDialog(
        title: "Authentication Failed",
        description: "Face doesn't match. Please try again.",
      );
    }
  }

  _fetchUserByName(String orgID) {
    FirebaseFirestore.instance
        .collection("users")
        .where("organizationId", isEqualTo: orgID)
        .get()
        .catchError((e) {
      log("Error: $e");
      setState(() => isMatching = false);
      CustomSnackBar.errorSnackBar("Something went wrong. Please try again.");
    }).then((snap) {
      if (snap.docs.isNotEmpty) {
        users.clear();
        for (var doc in snap.docs)
          users.add([UserModel.fromJson(doc.data()), 1]);
        _matchFaces();
      } else {
        setState(() => trialNumber = 1);
        _showFailureDialog(
          title: "User Not Found",
          description: "User not registered. Register first.",
        );
      }
    });
  }

  _showFailureDialog({required String title, required String description}) {
    setState(() => isMatching = false);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(description),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
    );
  }
}
